<?php header('Location: locales.php');
