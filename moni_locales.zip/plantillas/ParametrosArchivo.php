========================================================================================================================
    HEAD
========================================================================================================================
$name
http://www.baluart.net/articulo/urls-amigables-con-php
http://code.tutsplus.com/tutorials/using-htaccess-files-for-pretty-urls--net-6049
https://www.addedbytes.com/articles/for-beginners/url-rewriting-for-beginners/

<!--
<div class="panel panel-default infoWindow">
    <div class="panel-heading">
        <strong>Bar Manolo Mayo</strong>
        <span style="float : right;margin-left: 5px;">
            <a href=""><i class="fa fa-info" aria-hidden="true"></i> - Más información</a>
        </span>
    </div>
    <div class="panel-body">
        <table>
            <tr>
                <td max-width="130px">
                    <img src="img/local/bar-manolo-mayo.jpg" alt="Imagen" width="130px;">
                </td>
                <td>
                    <p>El Bar/Restaurante Manolo Mayo es un establecimiento que apuesta por la mezcla de lo tradicional junto a las novedades en la cocina tradicional.Cuenta con hotel en la planta superior</p>
                </td>
            </tr>
        </table>
    </div>
    <div class="panel-footer" style="bottom: 0px">
        Avenida de Sevilla, 29
        <span style="float : right;margin-left: 5px;">
            <a href=""><i class="fa fa-heart" aria-hidden="true"></i>Puntuación: 5</a>
        </span>
    </div>
</div>
-->



