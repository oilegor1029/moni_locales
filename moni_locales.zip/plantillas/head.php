<?php
 //Temporal hasta que lo pase a smarty
?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title>Moñi Locales | <?php echo $name; ?></title>
<!-- Stylesheets -->
<link rel="stylesheet" href="css/lib/font-awesome.min.css">
<link rel="stylesheet" href="css/lib/bootstrap.min.css">
<link rel="stylesheet" href="css/lib/toastr.min.css">
<link rel="stylesheet" href="css/style.css">
<!-- Google fonts -->
<link href='https://fonts.googleapis.com/css?family=PT+Serif:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>


