<!DOCTYPE html>
<html lang="es">
<head>
    <?php
    $name = "";
    include "plantillas/head.php";
    ?>
</head>
<body>
<?php include "plantillas/header.php";?>

<?php include "plantillas/footer.php"; ?>
</body>
</html>